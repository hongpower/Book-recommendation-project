from django.urls import path

from haystack.views import SearchView
#from .views import get_user_id

urlpatterns = [path("", SearchView(), name="haystack_search")]
#urlpatterns = [path("", )]
