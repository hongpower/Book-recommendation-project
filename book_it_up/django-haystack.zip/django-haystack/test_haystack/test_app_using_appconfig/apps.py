from django.apps import AppConfig


class SimpleTestAppConfig(AppConfig):
    name = "test_haystack.test_app_using_appconfig"
    verbose_name = "Simple test app using AppConfig"
