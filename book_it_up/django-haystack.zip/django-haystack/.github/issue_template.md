* [ ] Tested with the latest Haystack release
* [ ] Tested with the current Haystack master branch

## Expected behaviour

## Actual behaviour

## Steps to reproduce the behaviour

1.

## Configuration

* Operating system version:
* Search engine version:
* Python version:
* Django version:
* Haystack version:
