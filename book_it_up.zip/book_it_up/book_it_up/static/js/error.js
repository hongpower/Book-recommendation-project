$(function(){
    console.log('preference 페이지에서 15개 이상의 책에 대해서 평가를 내려주세요')
    location.href="/preference/?user_id=" + user_id;
})