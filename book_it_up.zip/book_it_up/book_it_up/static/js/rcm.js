$(function(){
    // 사용자가 접속한 user 정보를 가져온다(menu class의 a태그

})