mongo_user = 'jisu'
mongo_pw = '%40ghdwltn1'
ip_address = '59.6.7.229'
port_num = '27018'