from django.urls import path
from haystack.views import SearchView
from haystack.history_views import HisSearchView
#from .views import get_user_id

urlpatterns = [path("", SearchView(), name="haystack_search")]
urlpatterns = [path("history/", HisSearchView(), name="history_search")]
