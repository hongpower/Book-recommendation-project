from ..utils import check_solr


def setup():
    check_solr()
